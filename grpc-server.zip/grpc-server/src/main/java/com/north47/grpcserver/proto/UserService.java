package com.north47.grpcserver.proto;

import com.north47.proto.lib.CreateUserRequest;
import com.north47.proto.lib.UpdateUserRequest;
import com.north47.proto.lib.UserResponse;
import com.north47.proto.lib.UserServiceGrpc;
import io.grpc.stub.StreamObserver;
import net.devh.boot.grpc.server.service.GrpcService;

import java.util.UUID;

@GrpcService
public class UserService extends UserServiceGrpc.UserServiceImplBase {

    @Override
    public void createUser(CreateUserRequest request, StreamObserver<UserResponse> responseObserver) {
        UserResponse userResponse = UserResponse.newBuilder()
                .setId(UUID.randomUUID().toString())
                .setName(request.getName())
                .build();
        responseObserver.onNext(userResponse);
        responseObserver.onCompleted();
    }

    @Override
    public void updateUser(UpdateUserRequest request, StreamObserver<UserResponse> responseObserver) {
        super.updateUser(request, responseObserver);
    }
}
