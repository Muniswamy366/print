package com.arya.java12;

public class Java12 {
    public static void main(String[] args) {

        // String::indent
        // String::transform

        // Teeing Collector
        // To collect result from two collector

        // Files::mismatch

        // GMH Micro-benchmarking

    }
}
