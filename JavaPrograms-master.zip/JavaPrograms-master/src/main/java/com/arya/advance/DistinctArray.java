package com.arya.advance;


public class DistinctArray {

    public static void main(String[] args) {

        int[] arr = new int[]{1, 1, 1, 2, 2, 3, 4, 5};

        for (int i = 1; i < arr.length; i++) {
            for (int j = i - 1; j < i; j++) {
                if (arr[i] != arr[j]) {
                    System.out.print(arr[j] + " ");
                    break;
                }
            }
        }
        System.out.println(arr[arr.length - 1]);
    }
}
