package com.arya.simple;

public class AutoboxingTest {

    public static void main(String[] args) {

        // Example 1: == comparison pure primitive no autoboxing
        int i1 = 1;
        int i2 = 1;
        System.out.println("i1==i2 : " + (i1 == i2)); // true

        // Example 2: equality operator mixing object and primitive
        Integer num1 = 1; // autoboxing
        int num2 = 1;
        System.out.println("num1 == num2 : " + (num1 == num2)); // true

        // Example 3: special case - arises due to autoboxing in Java
        Integer obj1 = 1; // autoboxing will call Integer.valueOf()
        Integer obj2 = 1; // same call to Integer.valueOf() will return same
        // cached Object

        System.out.println("obj1 == obj2 : " + (obj1 == obj2)); // true

        // Example 4: equality operator - pure object comparison
        Integer one = new Integer(1); // no autoboxing
        Integer anotherOne = new Integer(1);
        System.out.println("one == anotherOne : " + (one == anotherOne)); // false

        Integer int1 = Integer.valueOf(1);
        Integer int2 = Integer.valueOf(1);
        System.out.println(int1 == int2);// true cached Object

        Integer integer1 = 127;
        Integer integer2 = 127;
        System.out.println(integer1 == integer2); // true returns cached object

        Integer integer11 = 128;
        Integer integer22 = 128;
        System.out.println(integer11 == integer22); // no cached object

    }
}
