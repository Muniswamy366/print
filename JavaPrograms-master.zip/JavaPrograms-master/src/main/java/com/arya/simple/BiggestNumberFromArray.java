package com.arya.simple;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

class BiggestNumberFromArray {

    static void printLargest(List<String> arr) {

        /*Collections.sort(arr, (X, Y) -> {
            return (Y + X).compareTo(X + Y); // We need descending order to get max.
        });*/

        Collections.sort(arr, (o1, o2) -> (o2+o1).compareTo(o1+o2));

        arr.forEach(System.out::print);
    }

    public static void main(String[] args) {

        // 6054854654
        printLargest(Arrays.asList("54", "546", "548", "60"));
        System.out.println();

        // 777776
        printLargest(Arrays.asList("7", "776", "7", "7"));
        System.out.println();

        // 998764543431
        printLargest(Arrays.asList("1", "34", "3", "98", "9", "76", "45", "4"));

    }
}