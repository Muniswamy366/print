package com.arya.string;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;

public class FirstNonRepeatedCharInString {

	public static void main(String[] args) {

		System.out.println(getFirstNonRepeatedChar("mumnin"));

	}

	public static char getFirstNonRepeatedChar(String str) {
		Map<Character, Integer> counts = new LinkedHashMap<>(str.length());

		for (char c : str.toCharArray()) {
			counts.put(c, counts.containsKey(c) ? counts.get(c) + 1 : 1);
		}

		for (Entry<Character, Integer> entry : counts.entrySet()) {
			if (entry.getValue() == 1) {
				return entry.getKey();
			}
		}
		throw new RuntimeException("didn't find any non repeated Character");
	}

	// 387. First Unique Character in a String
	public int firstUniqChar(String s) {
		if (s == null || s.length() == 0)
			return -1;

		int ans = Integer.MAX_VALUE;

		for (char ch = 'a'; ch <= 'z'; ch++){
			int index = s.indexOf(ch);
			if (index != -1 && index == s.lastIndexOf(ch))
				ans = Math.min(ans, index);
		}
		return ans == Integer.MAX_VALUE ? -1 : ans;
	}

}
