package com.arya.java13;

public class Java13 {
    public static void main(String[] args) {
        // Preview Switch expression, String::translateEscapes, String::transform
        // Text Blocks

    }
}
