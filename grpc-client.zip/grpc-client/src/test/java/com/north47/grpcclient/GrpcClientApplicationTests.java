package com.north47.grpcclient;

import com.north47.proto.lib.CreateUserRequest;
import com.north47.proto.lib.UserResponse;
import com.north47.proto.lib.UserServiceGrpc;
import net.devh.boot.grpc.client.inject.GrpcClient;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@SpringBootTest
class GrpcClientApplicationTests {

    @GrpcClient("userService")
    private UserServiceGrpc.UserServiceBlockingStub userServiceBlockingStub;

    @Test
    void test() {
        CreateUserRequest createUserRequest = CreateUserRequest.newBuilder()
                .setName("John")
                .build();
        UserResponse userResponse = userServiceBlockingStub.createUser(createUserRequest);
        assertEquals(createUserRequest.getName(), userResponse.getName());
        assertNotNull(userResponse.getId());
    }

}
