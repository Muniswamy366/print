package com.north47.grpcclient.dto;

public class UserResponseDTO {

    private String id;
    private String name;

    public UserResponseDTO() {
    }

    public UserResponseDTO(String id, String name) {
        this.id = id;
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
